# Level 0  Hello Ethernaut

Challenge URL = https://ethernaut.zeppelin.solutions/level/0xdf51a9e8ce57e7787e4a27dd19880fd7106b9a5c

# problem

The intro walks through the basics of funding wallet, deploying and intereacting with the smart contract using the browswer console.  
Need to get the password by reviewing the code.  

# Solution
Read password using await contract.password()
Pass password to authenticate function await contract.authenticate("password")
Submit the form using the page control "Submit instance"

